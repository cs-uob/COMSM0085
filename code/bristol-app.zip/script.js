let wards = fetch('https://opendata.bristol.gov.uk/api/records/1.0/search/?dataset=wards&rows=50')
  .then(response => response.json())
  .then(populateWards)
  .catch(err => console.log(err));

function populateWards(wards) {
  let buttons = new DocumentFragment();

  wards.records.forEach(w => {
      const [id, name] = [w.fields.ward_id, w.fields.name];
      const b = document.createElement("button");
      b.innerText = name; b.onclick = displayData(id, name);
      buttons.appendChild(b);
  });
  
  let nav = document.getElementById("nav");
  nav.textContent = '';
  nav.append(buttons);
}

function displayData(id, name) {
  
  function buildWardPopulationElement(records) {

    // Make heading
    let heading = document.createElement('h2');
    heading.innerText = 'Population';

    // Make table
    let table = document.createElement('table');
    table.setAttribute('id','populationTable');

    // Make table header
    let header = document.createElement('tr');
    header.innerHTML = '<th>Year</th><th>Population</th></tr>';
    table.appendChild(header);
    
    // Populate table
    records.filter(d => d.fields.mid_year >= 2015)
      .sort((x1, x2) => x1.fields.mid_year < x2.fields.mid_year ? -1 : 1)
      .forEach(r => {
        let year = document.createElement('td');
        year.innerText = r.fields.mid_year;
        let population = document.createElement('td');
        population.innerText = r.fields.population_estimate;

        let row = document.createElement('tr');
        row.append(year, population);
        table.appendChild(row);
    });
    
    let population = new DocumentFragment();
    population.append(heading, table);
    
    return population;
  }

  return function () {
    let wards = fetch(`https://opendata.bristol.gov.uk/api/records/1.0/search/?dataset=population-estimates-time-series-ward&q=&rows=20&facet=ward_2016_code&refine.ward_2016_code=${id}`)
      .then(response => response.json())
      .then(data => {
        let heading = document.createElement('h1');
        heading.innerText = name;
        
        let population = buildWardPopulationElement(data.records);

        let dataPane = document.getElementById("dataPane");
        dataPane.textContent = '';
        dataPane.append(heading, population);
      })
      .catch(err => console.log(err));
  }
}